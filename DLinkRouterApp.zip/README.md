# DLinkRouterApp (Android)

A tiny Android app that opens your router admin UI (`http://192.168.1.1`) in a WebView.

## Build steps (Android Studio)
1. Open **Android Studio** → **Open** → select the `DLinkRouterApp` folder.
2. Let Gradle sync (internet required).
3. From the run configuration, choose **app** and press **Run** to install on your device (USB debugging or emulator).
4. To build an APK: **Build** → **Build APK(s)**.

### Notes
- Requires Internet permission (already added).
- JavaScript and DOM storage are enabled for compatibility.
- Back button navigates WebView history.
- If your router uses a different IP, change it in `MainActivity.kt` (`webView.loadUrl(...)`).